

public interface SongFinishedListener {
	
	public void songDone();
	
}
